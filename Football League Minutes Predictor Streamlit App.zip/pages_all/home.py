# pages/home.py
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def show():
    """Display the home/dashboard page"""
    
    # Welcome section
    st.markdown("""
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                color: white; padding: 2rem; border-radius: 15px; margin-bottom: 2rem;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);">
        <h2 style="margin: 0; font-weight: 600;">🎯 Welcome to EFL League One Analytics</h2>
        <p style="margin: 0.5rem 0 0 0; font-size: 1.1rem; opacity: 0.9;">
            Advanced machine learning for player minutes prediction and squad optimization
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Key metrics row
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown("""
        <div class="metric-card">
            <h3 style="color: #667eea; margin: 0;">Model Accuracy</h3>
            <h1 style="margin: 0.5rem 0;">98.3%</h1>
            <p style="color: #666; margin: 0;">R² Score: 0.9834</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="metric-card">
            <h3 style="color: #667eea; margin: 0;">Prediction Error</h3>
            <h1 style="margin: 0.5rem 0;">95.5 min</h1>
            <p style="color: #666; margin: 0;">≈ 1 match average</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div class="metric-card">
            <h3 style="color: #667eea; margin: 0;">Training Data</h3>
            <h1 style="margin: 0.5rem 0;">14,512</h1>
            <p style="color: #666; margin: 0;">Player records</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown("""
        <div class="metric-card">
            <h3 style="color: #667eea; margin: 0;">Features</h3>
            <h1 style="margin: 0.5rem 0;">60</h1>
            <p style="color: #666; margin: 0;">Performance metrics</p>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    # Main content area
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("### 📊 Model Performance Overview")
        
        # Create sample performance data
        performance_data = {
            'Metric': ['R² Score', 'Mean Absolute Error', 'Root Mean Square Error', 'Mean Percentage Error'],
            'Value': [0.9834, 95.5, 145.2, 8.7],
            'Unit': ['(0-1)', 'minutes', 'minutes', '%'],
            'Status': ['Excellent', 'Very Good', 'Good', 'Excellent']
        }
        
        perf_df = pd.DataFrame(performance_data)
        
        # Create a bar chart
        fig_perf = go.Figure()
        
        colors = ['#28a745' if status == 'Excellent' else '#17a2b8' if status == 'Very Good' else '#ffc107' 
                 for status in perf_df['Status']]
        
        fig_perf.add_trace(go.Bar(
            x=perf_df['Metric'],
            y=perf_df['Value'],
            marker_color=colors,
            text=[f"{val} {unit}" for val, unit in zip(perf_df['Value'], perf_df['Unit'])],
            textposition='auto',
        ))
        
        fig_perf.update_layout(
            title="Model Performance Metrics",
            xaxis_title="Metrics",
            yaxis_title="Values",
            showlegend=False,
            height=350,
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
        )
        
        st.plotly_chart(fig_perf, use_container_width=True)
        
        # Player distribution visualization
        st.markdown("### 🎯 Player Minutes Distribution")
        
        # Sample data for player categories
        categories = ['Limited Role\n(<500 min)', 'Rotation Player\n(500-1500 min)', 
                     'Regular Starter\n(1500-2500 min)', 'Key Player\n(>2500 min)']
        percentages = [33, 30, 21, 16]
        colors_pie = ['#dc3545', '#ffc107', '#17a2b8', '#28a745']
        
        fig_pie = go.Figure(data=[go.Pie(
            labels=categories,
            values=percentages,
            hole=0.4,
            marker_colors=colors_pie,
            textinfo='label+percent',
            textposition='auto'
        )])
        
        fig_pie.update_layout(
            title="Player Role Distribution in EFL League One",
            height=400,
            showlegend=True,
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
        )
        
        st.plotly_chart(fig_pie, use_container_width=True)
    
    with col2:
        st.markdown("### 🚀 Quick Actions")
        
        # Quick action buttons
        if st.button("🔮 Single Player Prediction", use_container_width=True):
            st.session_state.page_selector = "🔮 Single Prediction"
            st.rerun()
        
        if st.button("📊 Batch Analysis", use_container_width=True):
            st.session_state.page_selector = "📊 Batch Analysis"
            st.rerun()
        
        if st.button("📈 Model Insights", use_container_width=True):
            st.session_state.page_selector = "📈 Model Insights"
            st.rerun()
        
        st.markdown("---")
        
        st.markdown("### 📈 Recent Activity")
        
        # Mock recent activity
        st.markdown("""
        <div style="background: #f8f9fa; padding: 1rem; border-radius: 10px; margin: 0.5rem 0;">
            <strong>John Smith</strong><br>
            <small>Predicted: 1,847 minutes</small><br>
            <small style="color: #666;">2 hours ago</small>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div style="background: #f8f9fa; padding: 1rem; border-radius: 10px; margin: 0.5rem 0;">
            <strong>Batch Analysis</strong><br>
            <small>25 players analyzed</small><br>
            <small style="color: #666;">5 hours ago</small>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div style="background: #f8f9fa; padding: 1rem; border-radius: 10px; margin: 0.5rem 0;">
            <strong>Sarah Johnson</strong><br>
            <small>Predicted: 892 minutes</small><br>
            <small style="color: #666;">1 day ago</small>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("---")
        
        st.markdown("### 💡 Tips & Insights")
        
        tips = [
            "Higher appearances strongly correlate with more minutes",
            "XG buildup is the second most important factor",
            "Consistency in minutes indicates established role",
            "Age-appearances interaction shows development phase"
        ]
        
        for tip in tips:
            st.markdown(f"💡 {tip}")
    
    # Features section
    st.markdown("---")
    st.markdown("### ⚡ Platform Features")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        <div style="background: white; padding: 2rem; border-radius: 15px; 
                    box-shadow: 0 5px 15px rgba(0,0,0,0.08); text-align: center;">
            <h2 style="color: #667eea;">🔮</h2>
            <h4>Single Player Prediction</h4>
            <p>Get detailed minutes prediction for individual players with confidence intervals and insights.</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div style="background: white; padding: 2rem; border-radius: 15px; 
                    box-shadow: 0 5px 15px rgba(0,0,0,0.08); text-align: center;">
            <h2 style="color: #667eea;">📊</h2>
            <h4>Batch Analysis</h4>
            <p>Analyze multiple players simultaneously with CSV upload and comprehensive reports.</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div style="background: white; padding: 2rem; border-radius: 15px; 
                    box-shadow: 0 5px 15px rgba(0,0,0,0.08); text-align: center;">
            <h2 style="color: #667eea;">📈</h2>
            <h4>Model Insights</h4>
            <p>Understand feature importance and model behavior with detailed analytics.</p>
        </div>
        """, unsafe_allow_html=True)
    
    # Business applications
    st.markdown("---")
    st.markdown("### 💼 Business Applications")
    
    applications = [
        {
            "title": "Squad Planning",
            "description": "Optimize training resources and rotation strategies based on predicted playing time",
            "icon": "👥"
        },
        {
            "title": "Transfer Strategy", 
            "description": "Assess potential signings and their likely contribution to the team",
            "icon": "💰"
        },
        {
            "title": "Player Development",
            "description": "Identify opportunities for young players and plan development pathways",
            "icon": "📚"
        },
        {
            "title": "Performance Analysis",
            "description": "Monitor player progression and identify factors affecting playing time",
            "icon": "📊"
        }
    ]
    
    for i in range(0, len(applications), 2):
        col1, col2 = st.columns(2)
        
        with col1:
            app = applications[i]
            st.markdown(f"""
            <div style="background: linear-gradient(135deg, #f8f9fa, #e9ecef); 
                        padding: 1.5rem; border-radius: 15px; margin: 0.5rem 0;
                        border-left: 4px solid #667eea;">
                <h4>{app['icon']} {app['title']}</h4>
                <p style="color: #666; margin: 0;">{app['description']}</p>
            </div>
            """, unsafe_allow_html=True)
        
        if i + 1 < len(applications):
            with col2:
                app = applications[i + 1]
                st.markdown(f"""
                <div style="background: linear-gradient(135deg, #f8f9fa, #e9ecef); 
                            padding: 1.5rem; border-radius: 15px; margin: 0.5rem 0;
                            border-left: 4px solid #667eea;">
                    <h4>{app['icon']} {app['title']}</h4>
                    <p style="color: #666; margin: 0;">{app['description']}</p>
                </div>
                """, unsafe_allow_html=True)
    
    # Footer section
    st.markdown("---")
    st.markdown("""
    <div style="text-align: center; color: #666; padding: 2rem;">
        <p style="font-size: 1.1rem; margin-bottom: 1rem;">
            🎯 <strong>Ready to start predicting?</strong>
        </p>
        <p>
            Use the navigation menu to access single player predictions, batch analysis, or explore model insights.
        </p>
    </div>
    """, unsafe_allow_html=True)