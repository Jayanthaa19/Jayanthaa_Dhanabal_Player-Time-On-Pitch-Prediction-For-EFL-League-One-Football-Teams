# pages/single_prediction.py
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import joblib

def load_models():
    """Load the trained model and preprocessors"""
    try:
        model = joblib.load('selected_files/corrected_gradient_boosting_model.joblib')
        scaler = joblib.load('selected_files/corrected_feature_scaler.joblib')
        feature_names = joblib.load('selected_files/corrected_feature_names.joblib')
        return model, scaler, feature_names, True
    except FileNotFoundError:
        st.error("⚠️ Model files not found! Please ensure model files are in the correct directory.")
        return None, None, None, False

def show():
    """Display the single player prediction page"""
    
    st.markdown("""
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                color: white; padding: 2rem; border-radius: 15px; margin-bottom: 2rem;">
        <h2 style="margin: 0;">🔮 Single Player Minutes Prediction</h2>
        <p style="margin: 0.5rem 0 0 0;">Enter player details to predict season minutes with ML-powered accuracy</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Load models
    model, scaler, feature_names, models_loaded = load_models()
    
    if not models_loaded:
        st.error("Cannot load models. Please check if model files exist in the selected_files directory.")
        return
    
    # Initialize session state for predictions history
    if 'predictions_history' not in st.session_state:
        st.session_state.predictions_history = []
    
    # Create input form
    with st.container():
        st.markdown("### 📝 Player Information")
        
        # Basic Information
        col1, col2, col3 = st.columns(3)
        
        with col1:
            player_name = st.text_input("👤 Player Name", value="", placeholder="Enter player's full name")
            age = st.slider("🎂 Age", min_value=16, max_value=40, value=25, help="Player's current age")
            
        with col2:
            position_options = ['GK', 'DEF', 'MID', 'FWD', 'OTHER']
            position = st.selectbox("⚽ Primary Position", position_options, index=2)
            
        with col3:
            appearances = st.slider("📊 Season Appearances", min_value=0, max_value=50, value=20, 
                                  help="Number of appearances this season")
        
        st.markdown("---")
        
        # Performance Metrics
        st.markdown("### 📈 Performance Metrics")
        
        col4, col5, col6 = st.columns(3)
        
        with col4:
            st.markdown("**🎯 Expected Goals & Assists**")
            xgbuildup = st.slider("XG Buildup", min_value=0.0, max_value=20.0, value=5.0, step=0.1,
                                help="Expected goals buildup contribution")
            xgchain = st.slider("XG Chain", min_value=0.0, max_value=30.0, value=8.0, step=0.1,
                              help="Expected goals chain involvement")
            
        with col5:
            st.markdown("**⏱️ Match-Level Performance**")
            avg_minutes_per_match = st.slider("Avg Minutes per Match", min_value=0.0, max_value=90.0, 
                                             value=60.0, step=1.0)
            minutes_coefficient_variation = st.slider("Minutes Consistency", min_value=0.0, max_value=2.0, 
                                                     value=0.5, step=0.01,
                                                     help="Lower values indicate more consistent playing time")
            
        with col6:
            st.markdown("**🔥 Advanced Metrics**")
            pressures_90 = st.slider("Pressures per 90min", min_value=0.0, max_value=50.0, value=15.0, step=0.5,
                                    help="Defensive pressures applied per 90 minutes")
            long_balls_90 = st.slider("Long Balls per 90min", min_value=0.0, max_value=20.0, value=5.0, step=0.1,
                                     help="Long balls attempted per 90 minutes")
        
        st.markdown("---")
        
        # Career Information
        st.markdown("### 🏆 Career Information")
        
        col7, col8, col9 = st.columns(3)
        
        with col7:
            total_records = st.slider("Career Seasons", min_value=1, max_value=15, value=3,
                                    help="Total number of professional seasons")
            record_number = st.slider("Current Season Number", min_value=1, max_value=total_records, value=2)
            
        with col8:
            is_latest_record = st.checkbox("Latest Record", value=True, 
                                         help="Is this the player's most recent season?")
            cumulative_appearances = st.slider("Career Total Appearances", min_value=0, max_value=500, value=60,
                                              help="Total career appearances across all seasons")
            
        with col9:
            career_stage_options = ['Early_Career', 'Mid_Career', 'Late_Career']
            career_stage = st.selectbox("Career Stage", career_stage_options, index=1,
                                      help="Current phase of player's career")
        
        # Prepare input data
        input_data = {
            'player_name': player_name,
            'age': age,
            'position': position,
            'player_season_appearances': appearances,
            'player_season_xgbuildup': xgbuildup,
            'player_season_xgchain': xgchain,
            'match_avg_minutes_per_match': avg_minutes_per_match,
            'match_minutes_coefficient_variation': minutes_coefficient_variation,
            'player_season_fhalf_pressures_90': pressures_90,
            'player_season_long_balls_90': long_balls_90,
            'total_records_per_player': total_records,
            'player_record_number': record_number,
            'is_latest_record': 1 if is_latest_record else 0,
            'cumulative_appearances': cumulative_appearances,
            'career_stage_category': career_stage,
            'age_appearances_interaction': age * appearances
        }
        
        # Prediction button
        st.markdown("---")
        
        col_pred1, col_pred2, col_pred3 = st.columns([1, 2, 1])
        
        with col_pred2:
            predict_button = st.button("🚀 Predict Season Minutes", 
                                     use_container_width=True, 
                                     type="primary",
                                     help="Generate ML prediction for this player")
        
        # Make prediction
        if predict_button:
            if not player_name.strip():
                st.error("❌ Please enter a player name")
                return
            
            with st.spinner("🔮 Calculating prediction..."):
                try:
                    prediction, conf_lower, conf_upper = make_prediction(input_data, model, scaler, feature_names)
                    
                    # Store in history
                    prediction_record = {
                        'timestamp': datetime.now(),
                        'player_name': input_data['player_name'],
                        'prediction': prediction,
                        'confidence_lower': conf_lower,
                        'confidence_upper': conf_upper,
                        'input_data': input_data.copy()
                    }
                    st.session_state.predictions_history.append(prediction_record)
                    
                    # Display results
                    display_prediction_results(prediction, conf_lower, conf_upper, input_data)
                    
                except Exception as e:
                    st.error(f"❌ Prediction failed: {str(e)}")
                    st.info("Please check your input values and try again.")

def prepare_features_for_prediction(input_data, feature_names):
    """Prepare input features for model prediction"""
    
    # Create a dataframe with default values
    feature_df = pd.DataFrame(0, index=[0], columns=feature_names)
    
    # Map input data to features
    feature_mapping = {
        'player_season_appearances': input_data.get('player_season_appearances', 0),
        'player_season_xgbuildup': input_data.get('player_season_xgbuildup', 0),
        'match_avg_minutes_per_match': input_data.get('match_avg_minutes_per_match', 0),
        'match_minutes_coefficient_variation': input_data.get('match_minutes_coefficient_variation', 0),
        'player_season_360_minutes': input_data.get('player_season_appearances', 0) * 90,  # Estimate
        'cumulative_appearances': input_data.get('cumulative_appearances', 0),
        'player_season_xgchain': input_data.get('player_season_xgchain', 0),
        'player_season_fhalf_pressures_90': input_data.get('player_season_fhalf_pressures_90', 0),
        'age_appearances_interaction': input_data.get('age_appearances_interaction', 0),
        'total_records_per_player': input_data.get('total_records_per_player', 1),
        'player_record_number': input_data.get('player_record_number', 1),
        'is_latest_record': input_data.get('is_latest_record', 1),
        'player_season_long_balls_90': input_data.get('player_season_long_balls_90', 0),
        'age': input_data.get('age', 25)
    }
    
    # Apply mappings with safe column checking
    for feature, value in feature_mapping.items():
        if feature in feature_df.columns:
            feature_df[feature] = value
    
    # Handle categorical variables
    if 'career_stage_category' in input_data:
        career_stage = input_data['career_stage_category']
        for stage in ['Early_Career', 'Mid_Career', 'Late_Career']:
            col_name = f'career_stage_category_{stage}'
            if col_name in feature_df.columns:
                feature_df[col_name] = 1 if career_stage == stage else 0
    
    # Fill any remaining NaN values
    feature_df = feature_df.fillna(0)
    
    return feature_df

def make_prediction(input_data, model, scaler, feature_names):
    """Make prediction using the trained model"""
    
    # Prepare features
    feature_df = prepare_features_for_prediction(input_data, feature_names)
    
    # Scale features
    features_scaled = scaler.transform(feature_df)
    
    # Make prediction
    prediction = model.predict(features_scaled)[0]
    
    # Calculate confidence interval (approximate)
    typical_error = 95  # From model evaluation
    confidence_lower = max(0, prediction - typical_error)
    confidence_upper = prediction + typical_error
    
    return prediction, confidence_lower, confidence_upper

def display_prediction_results(prediction, conf_lower, conf_upper, input_data):
    """Display the prediction results with visualizations"""
    
    st.markdown("---")
    st.markdown("## 🎯 Prediction Results")
    
    # Main result card
    st.markdown(f"""
    <div style="background: linear-gradient(135deg, #28a745, #20c997); 
                color: white; padding: 2rem; border-radius: 15px; margin: 1rem 0;
                text-align: center; box-shadow: 0 10px 30px rgba(0,0,0,0.2);">
        <h1 style="margin: 0; font-size: 3rem; font-weight: 700;">{prediction:.0f}</h1>
        <h3 style="margin: 0.5rem 0;">Season Minutes for {input_data['player_name']}</h3>
        <p style="margin: 0; font-size: 1.1rem; opacity: 0.9;">
            Confidence Range: {conf_lower:.0f} - {conf_upper:.0f} minutes
        </p>
        <p style="margin: 0.5rem 0 0 0; font-size: 1rem;">
            ≈ {prediction/90:.1f} full matches
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Visualizations
    col1, col2 = st.columns(2)
    
    with col1:
        # Gauge chart
        fig_gauge = create_gauge_chart(prediction, input_data['player_name'])
        st.plotly_chart(fig_gauge, use_container_width=True)
    
    with col2:
        # Category comparison chart
        fig_comparison = create_category_comparison(prediction)
        st.plotly_chart(fig_comparison, use_container_width=True)
    
    # Interpretation section
    st.markdown("### 🧠 Prediction Interpretation")
    
    col1, col2 = st.columns(2)
    
    with col1:
        interpretations = interpret_prediction(prediction, input_data)
        for interpretation in interpretations:
            st.markdown(f"• {interpretation}")
    
    with col2:
        st.markdown("#### 📊 Key Input Factors")
        st.markdown(f"• **Age**: {input_data['age']} years")
        st.markdown(f"• **Position**: {input_data['position']}")
        st.markdown(f"• **Appearances**: {input_data['player_season_appearances']}")
        st.markdown(f"• **Avg Minutes/Match**: {input_data['match_avg_minutes_per_match']:.0f}")
        st.markdown(f"• **Career Stage**: {input_data['career_stage_category']}")
    
    # Recommendations
    st.markdown("### 💡 Recommendations")
    
    recommendations = generate_recommendations(prediction, input_data)
    
    for i, rec in enumerate(recommendations):
        color = "#28a745" if i == 0 else "#17a2b8" if i == 1 else "#ffc107"
        st.markdown(f"""
        <div style="background: {color}; color: white; padding: 1rem; 
                    border-radius: 10px; margin: 0.5rem 0;">
            <strong>{rec['title']}</strong><br>
            {rec['description']}
        </div>
        """, unsafe_allow_html=True)

def create_gauge_chart(prediction, player_name):
    """Create a gauge chart for the prediction"""
    
    fig = go.Figure(go.Indicator(
        mode = "gauge+number+delta",
        value = prediction,
        domain = {'x': [0, 1], 'y': [0, 1]},
        title = {'text': f"Predicted Minutes<br><sub>{player_name}</sub>"},
        delta = {'reference': 1800, 'relative': True},
        gauge = {
            'axis': {'range': [None, 3500]},
            'bar': {'color': "#667eea"},
            'steps': [
                {'range': [0, 500], 'color': "#f8d7da"},
                {'range': [500, 1500], 'color': "#fff3cd"},
                {'range': [1500, 2500], 'color': "#d1ecf1"},
                {'range': [2500, 3500], 'color': "#d4edda"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': prediction
            }
        }
    ))
    
    fig.update_layout(
        height=400,
        title="Season Minutes Prediction",
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
    )
    
    return fig

def create_category_comparison(prediction):
    """Create a comparison chart showing player category"""
    
    categories = ['Limited Role', 'Rotation', 'Regular', 'Key Player']
    ranges = [500, 1500, 2500, 3500]
    colors = ['#dc3545', '#ffc107', '#17a2b8', '#28a745']
    
    # Determine which category the prediction falls into
    category_idx = 0
    for i, range_val in enumerate(ranges):
        if prediction <= range_val:
            category_idx = i
            break
    
    fig = go.Figure()
    
    # Add bars for each category
    for i, (cat, range_val, color) in enumerate(zip(categories, ranges, colors)):
        opacity = 1.0 if i == category_idx else 0.3
        
        fig.add_trace(go.Bar(
            x=[cat],
            y=[range_val],
            marker_color=color,
            opacity=opacity,
            name=cat,
            showlegend=False
        ))
    
    # Add prediction line
    fig.add_hline(y=prediction, line_dash="dash", line_color="red", 
                  annotation_text=f"Your Player: {prediction:.0f} min")
    
    fig.update_layout(
        title="Player Category Comparison",
        xaxis_title="Player Categories",
        yaxis_title="Season Minutes",
        height=400,
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
    )
    
    return fig

def interpret_prediction(prediction, player_data):
    """Provide interpretation of the prediction"""
    
    interpretations = []
    
    # Minutes category
    if prediction < 500:
        category = "Limited Role Player"
        interpretation = "Likely to be used sparingly, mainly as substitute or in cup games"
    elif prediction < 1500:
        category = "Squad Rotation Player"
        interpretation = "Regular squad member with rotational starts and substitute appearances"
    elif prediction < 2500:
        category = "Regular Starter"
        interpretation = "Key player expected to start most matches throughout the season"
    else:
        category = "Key Player"
        interpretation = "Essential player likely to play almost every match when fit"
    
    interpretations.append(f"**Player Category**: {category}")
    interpretations.append(f"**Role**: {interpretation}")
    
    # Age-based insights
    age = player_data.get('age', 25)
    if age < 21:
        interpretations.append(f"**Age Factor**: At {age}, this player is developing. Minutes may increase with experience")
    elif age > 32:
        interpretations.append(f"**Age Factor**: At {age}, this experienced player's minutes may depend on fitness")
    
    return interpretations

def generate_recommendations(prediction, player_data):
    """Generate actionable recommendations based on prediction"""
    
    recommendations = []
    
    if prediction > 2500:
        recommendations.extend([
            {"title": "🌟 Key Player Management", 
             "description": "Prioritize in training programs and fitness monitoring. Plan rest periods carefully."},
            {"title": "💪 Injury Prevention", 
             "description": "Implement comprehensive fitness and recovery protocols given high expected workload."},
            {"title": "🎯 Performance Optimization", 
             "description": "Focus on maintaining peak performance levels throughout the season."}
        ])
    elif prediction > 1500:
        recommendations.extend([
            {"title": "⚡ Regular Development", 
             "description": "Maintain consistent training and development programs."},
            {"title": "🔄 Rotation Planning", 
             "description": "Plan strategic rotation to maximize performance in key matches."},
            {"title": "📈 Skill Enhancement", 
             "description": "Focus on specific skills to potentially increase playing time."}
        ])
    else:
        recommendations.extend([
            {"title": "🎯 Development Focus", 
             "description": "Concentrate on specific skill development and fitness improvement."},
            {"title": "🏆 Opportunity Preparation", 
             "description": "Stay ready for increased opportunities due to injuries or form changes."},
            {"title": "📚 Learning Priority", 
             "description": "Use training time effectively to develop technical and tactical understanding."}
        ])
    
    return recommendations