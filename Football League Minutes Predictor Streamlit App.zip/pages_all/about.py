# pages/about.py
import streamlit as st
from datetime import datetime

def show():
    """Display the about page"""
    
    st.markdown("""
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                color: white; padding: 2rem; border-radius: 15px; margin-bottom: 2rem;">
        <h2 style="margin: 0;">📋 About the EFL Player Minutes Predictor</h2>
        <p style="margin: 0.5rem 0 0 0;">Advanced machine learning for football analytics and player development</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Project overview
    st.markdown("### 🎯 Project Overview")
    
    st.markdown("""
    The EFL League One Player Minutes Predictor is an advanced machine learning system designed to help 
    football clubs predict how many minutes their players will accumulate during a season. This tool 
    combines comprehensive performance data with sophisticated temporal analysis to provide accurate, 
    actionable insights for squad planning and player development.
    
    Built specifically for EFL League One teams, this system addresses the unique challenges of lower-league 
    football where resource optimization and player development are crucial for success.
    """)
    
    # Key features section
    st.markdown("---")
    st.markdown("### ⚡ Key Features")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        #### 🤖 Machine Learning Capabilities
        - **98.3% Prediction Accuracy** with R² score of 0.9834
        - **95-minute Average Error** (approximately 1 match)
        - **60 Engineered Features** from comprehensive data analysis
        - **Gradient Boosting Algorithm** optimized for football data
        
        #### 📊 Data Sources
        - **14,512 Player Records** from EFL League One
        - **Match-Level Performance** metrics and statistics
        - **Career Progression** tracking and temporal analysis
        - **Team Context** including playing style and tactics
        """)
    
    with col2:
        st.markdown("""
        #### 🎯 Business Applications
        - **Squad Planning** and resource allocation
        - **Transfer Strategy** and recruitment decisions
        - **Player Development** pathway optimization
        - **Performance Analysis** and opportunity identification
        
        #### 🔒 Security & Privacy
        - **Secure Authentication** with role-based access
        - **Data Privacy** compliance and protection
        - **No Personal Data** storage beyond session
        - **Transparent Processing** with explainable AI
        """)
    
    # Technical architecture
    st.markdown("---")
    st.markdown("### 🏗️ Technical Architecture")
    
    tab1, tab2, tab3 = st.tabs(["🧠 Machine Learning", "💻 Technology Stack", "🔄 Data Pipeline"])
    
    with tab1:
        st.markdown("""
        #### Machine Learning Framework
        
        **Model Architecture**
        - **Algorithm**: Gradient Boosting Regressor (scikit-learn)
        - **Training Data**: 14,512 player season records
        - **Feature Engineering**: 60 carefully crafted features
        - **Validation**: 5-fold cross-validation with temporal holdout
        
        **Feature Categories**
        1. **Historical Performance** (89.2% importance)
           - Season appearances, total minutes, career statistics
        2. **Current Form Indicators** (6.8% importance)
           - Expected goals, defensive actions, recent performance
        3. **Career Context** (4.0% importance)
           - Age interactions, career stage, experience level
        
        **Model Performance**
        - **R² Score**: 0.9834 (excellent explanatory power)
        - **Mean Absolute Error**: 95.5 minutes
        - **Root Mean Square Error**: 145.2 minutes
        - **Cross-Validation Stability**: ±0.012 variance
        """)
    
    with tab2:
        st.markdown("""
        #### Technology Stack
        
        **Frontend & Interface**
        - **Streamlit**: Interactive web application framework
        - **Plotly**: Advanced data visualization and charts
        - **Custom CSS**: Professional UI design and styling
        - **Responsive Design**: Multi-device compatibility
        
        **Machine Learning & Data**
        - **Python 3.8+**: Core programming language
        - **scikit-learn**: Machine learning algorithms
        - **pandas & NumPy**: Data manipulation and analysis
        - **joblib**: Model serialization and persistence
        
        **Authentication & Security**
        - **Custom Auth System**: Secure user management
        - **Role-Based Access**: Differentiated user permissions
        - **Session Management**: Secure state handling
        - **Data Encryption**: Password hashing and protection
        """)
    
    with tab3:
        st.markdown("""
        #### Data Processing Pipeline
        
        **Data Collection**
        1. Player season statistics from official EFL sources
        2. Match-level performance data and metrics
        3. Career progression and historical records
        4. Team tactical information and context
        
        **Data Preprocessing**
        1. **Cleaning**: Missing value imputation, outlier detection
        2. **Feature Engineering**: Interaction terms, temporal features
        3. **Scaling**: StandardScaler for numerical features
        4. **Encoding**: One-hot encoding for categorical variables
        
        **Model Training**
        1. **Feature Selection**: Importance-based filtering
        2. **Hyperparameter Tuning**: Grid search optimization
        3. **Validation**: Cross-validation and temporal testing
        4. **Deployment**: Model serialization and web integration
        """)
    
    # Research background
    st.markdown("---")
    st.markdown("### 🎓 Research Background")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("""
        #### Academic Foundation
        
        This project was developed as part of an **MSc Artificial Intelligence dissertation** focusing on:
        
        - **Sports Analytics**: Application of AI to football performance analysis
        - **Predictive Modeling**: Advanced machine learning for player assessment
        - **EFL League One Analysis**: Specific focus on English third-tier football
        - **Temporal Data Mining**: Career progression and development patterns
        
        #### Research Contributions
        
        - **Novel Feature Engineering**: Creation of football-specific interaction terms
        - **Temporal Analysis**: Career stage modeling for player development
        - **Model Interpretability**: Explainable AI for football decision-making
        - **Business Application**: Practical implementation for club operations
        """)
    
    with col2:
        st.markdown("""
        <div style="background: #f8f9fa; padding: 1.5rem; border-radius: 15px; text-align: center;">
            <h4 style="color: #667eea;">📚 Academic Details</h4>
            <p><strong>Degree</strong><br>MSc Artificial Intelligence</p>
            <p><strong>Focus Area</strong><br>Sports Analytics & ML</p>
            <p><strong>Research Period</strong><br>2024-2025</p>
            <p><strong>Dataset Size</strong><br>14,512 records</p>
            <p><strong>Model Accuracy</strong><br>98.3% R² Score</p>
        </div>
        """, unsafe_allow_html=True)
    
    # Development timeline
    st.markdown("---")
    st.markdown("### 📅 Development Timeline")
    
    timeline_events = [
        {"date": "January 2024", "event": "Data Collection & Cleaning", "description": "Gathered EFL League One data"},
        {"date": "March 2024", "event": "Feature Engineering", "description": "Created 60+ predictive features"},
        {"date": "May 2024", "event": "Model Development", "description": "Trained and validated ML models"},
        {"date": "July 2024", "event": "Web Application", "description": "Built Streamlit interface"},
        {"date": "August 2024", "event": "Authentication System", "description": "Added user management"},
        {"date": "Present", "event": "Continuous Improvement", "description": "Ongoing enhancements"}
    ]
    
    for i, event in enumerate(timeline_events):
        col1, col2, col3 = st.columns([1, 3, 2])
        
        with col1:
            st.markdown(f"**{event['date']}**")
        
        with col2:
            st.markdown(f"**{event['event']}**")
        
        with col3:
            st.markdown(f"*{event['description']}*")
        
        if i < len(timeline_events) - 1:
            st.markdown("---")
    
    # Future roadmap
    st.markdown("---")
    st.markdown("### 🚀 Future Roadmap")
    
    roadmap_items = [
        {
            "quarter": "Q3 2025",
            "title": "Real-Time Integration",
            "description": "Live match data and training metrics integration",
            "status": "planned"
        },
        {
            "quarter": "Q4 2025", 
            "title": "Injury Prediction",
            "description": "Machine learning model for injury risk assessment",
            "status": "research"
        },
        {
            "quarter": "Q1 2026",
            "title": "Multi-League Expansion", 
            "description": "Extend to Championship and League Two",
            "status": "planned"
        },
        {
            "quarter": "Q2 2026",
            "title": "Mobile Application",
            "description": "Native iOS and Android applications",
            "status": "concept"
        }
    ]
    
    for item in roadmap_items:
        status_color = "#28a745" if item["status"] == "planned" else "#ffc107" if item["status"] == "research" else "#6c757d"
        
        st.markdown(f"""
        <div style="background: white; padding: 1.5rem; border-radius: 10px; margin: 1rem 0;
                    border-left: 4px solid {status_color}; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h4 style="margin: 0; color: #333;">{item['title']}</h4>
                <span style="background: {status_color}; color: white; padding: 0.25rem 0.75rem; 
                           border-radius: 15px; font-size: 0.8rem; text-transform: uppercase;">
                    {item['status']}
                </span>
            </div>
            <p style="margin: 0.5rem 0 0 0; color: #666;">{item['description']}</p>
            <small style="color: #999;">Target: {item['quarter']}</small>
        </div>
        """, unsafe_allow_html=True)
    
    # Contact and support
    st.markdown("---")
    st.markdown("### 📞 Contact & Support")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        #### 💬 Get in Touch
        
        For questions, feedback, or technical support:
        
        - **Email**: support@efl-predictor.com
        - **GitHub**: github.com/efl-predictor
        - **Documentation**: docs.efl-predictor.com
        - **LinkedIn**: linkedin.com/company/efl-predictor
        
        #### 🐛 Report Issues
        
        Found a bug or have a feature request?
        - Create an issue on GitHub
        - Use the feedback form in the app
        - Email technical details to support
        """)
    
    with col2:
        st.markdown("""
        #### 🎓 Academic Collaboration
        
        Interested in research collaboration?
        
        - **University Partnerships**: Available for academic projects
        - **Data Sharing**: Anonymized datasets for research
        - **Publication**: Co-authorship opportunities
        - **Student Projects**: Mentorship and guidance
        
        #### 📊 Business Inquiries
        
        Commercial applications and partnerships:
        - **Club Implementations**: Custom solutions
        - **League Partnerships**: Multi-team deployments
        - **Consulting Services**: Analytics expertise
        """)
    
    # Legal and compliance
    st.markdown("---")
    st.markdown("### ⚖️ Legal & Compliance")
    
    st.markdown("""
    <div style="background: #f8f9fa; padding: 2rem; border-radius: 15px;">
        <h4 style="color: #667eea; margin-bottom: 1rem;">📜 Terms & Conditions</h4>
        
        <p><strong>Data Privacy:</strong> This application processes football performance data in compliance with GDPR and data protection regulations. No personal identifying information is stored permanently.</p>
        
        <p><strong>Academic Use:</strong> This project was developed for academic research purposes as part of an MSc dissertation. Commercial use requires proper licensing.</p>
        
        <p><strong>Accuracy Disclaimer:</strong> While the model achieves 98.3% accuracy, predictions are for guidance only. Football involves unpredictable elements that cannot be fully modeled.</p>
        
        <p><strong>Copyright:</strong> © 2024-2025 EFL Player Minutes Predictor. All rights reserved. Source code available under academic license.</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Footer
    st.markdown("---")
    st.markdown(f"""
    <div style="text-align: center; color: #666; padding: 2rem;">
        <p style="font-size: 1.1rem; margin-bottom: 1rem;">
            ⚽ <strong>EFL League One Player Minutes Predictor</strong>
        </p>
        <p>
            Version 1.0.0 | Last Updated: {datetime.now().strftime('%B %Y')} | 
            Built with ❤️ for football analytics
        </p>
        <p style="font-size: 0.9rem; margin-top: 1rem;">
            Empowering football clubs with AI-driven insights for better decision making
        </p>
    </div>
    """, unsafe_allow_html=True)