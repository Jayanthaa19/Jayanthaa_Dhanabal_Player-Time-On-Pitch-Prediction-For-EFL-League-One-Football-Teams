# pages/batch_prediction.py
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import joblib
from io import StringIO

def load_models():
    """Load the trained model and preprocessors"""
    try:
        model = joblib.load('selected_files/corrected_gradient_boosting_model.joblib')
        scaler = joblib.load('selected_files/corrected_feature_scaler.joblib')
        feature_names = joblib.load('selected_files/corrected_feature_names.joblib')
        return model, scaler, feature_names, True
    except FileNotFoundError:
        st.error("⚠️ Model files not found! Please ensure model files are in the correct directory.")
        return None, None, None, False

def prepare_features_for_prediction(input_data, feature_names):
    """Prepare input features for model prediction"""
    feature_df = pd.DataFrame(0, index=[0], columns=feature_names)
    
    feature_mapping = {
        'player_season_appearances': input_data.get('player_season_appearances', 0),
        'player_season_xgbuildup': input_data.get('player_season_xgbuildup', 0),
        'match_avg_minutes_per_match': input_data.get('match_avg_minutes_per_match', 0),
        'match_minutes_coefficient_variation': input_data.get('match_minutes_coefficient_variation', 0),
        'player_season_360_minutes': input_data.get('player_season_appearances', 0) * 90,
        'cumulative_appearances': input_data.get('cumulative_appearances', 0),
        'player_season_xgchain': input_data.get('player_season_xgchain', 0),
        'player_season_fhalf_pressures_90': input_data.get('player_season_fhalf_pressures_90', 0),
        'age_appearances_interaction': input_data.get('age_appearances_interaction', 0),
        'total_records_per_player': input_data.get('total_records_per_player', 1),
        'player_record_number': input_data.get('player_record_number', 1),
        'is_latest_record': input_data.get('is_latest_record', 1),
        'player_season_long_balls_90': input_data.get('player_season_long_balls_90', 0),
        'age': input_data.get('age', 25)
    }
    
    for feature, value in feature_mapping.items():
        if feature in feature_df.columns:
            feature_df[feature] = value
    
    if 'career_stage_category' in input_data:
        career_stage = input_data['career_stage_category']
        for stage in ['Early_Career', 'Mid_Career', 'Late_Career']:
            col_name = f'career_stage_category_{stage}'
            if col_name in feature_df.columns:
                feature_df[col_name] = 1 if career_stage == stage else 0
    
    feature_df = feature_df.fillna(0)
    return feature_df

def make_prediction(input_data, model, scaler, feature_names):
    """Make prediction using the trained model"""
    feature_df = prepare_features_for_prediction(input_data, feature_names)
    features_scaled = scaler.transform(feature_df)
    prediction = model.predict(features_scaled)[0]
    
    typical_error = 95
    confidence_lower = max(0, prediction - typical_error)
    confidence_upper = prediction + typical_error
    
    return prediction, confidence_lower, confidence_upper

def show():
    """Display the batch prediction page"""
    
    st.markdown("""
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                color: white; padding: 2rem; border-radius: 15px; margin-bottom: 2rem;">
        <h2 style="margin: 0;">📊 Batch Player Analysis</h2>
        <p style="margin: 0.5rem 0 0 0;">Analyze multiple players simultaneously with comprehensive reporting</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Load models
    model, scaler, feature_names, models_loaded = load_models()
    
    if not models_loaded:
        st.error("Cannot load models. Please check if model files exist in the selected_files directory.")
        return
    
    # Initialize session state
    if 'batch_results' not in st.session_state:
        st.session_state.batch_results = None
    
    # File upload section
    st.markdown("### 📁 Upload Player Data")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("""
        Upload a CSV file containing player data. The system will automatically predict minutes for all players.
        
        **Required columns**: `player_name`, `age`, `player_season_appearances`, `position`
        
        **Optional columns**: All other performance metrics (system will use intelligent defaults)
        """)
        
        uploaded_file = st.file_uploader(
            "Choose a CSV file", 
            type="csv",
            help="Upload your player data in CSV format"
        )
    
    with col2:
        st.markdown("#### 📋 Sample Template")
        
        # Create sample template
        sample_data = pd.DataFrame({
            'player_name': ['John Smith', 'Jane Doe', 'Mike Johnson', 'Sarah Wilson'],
            'age': [25, 22, 28, 24],
            'position': ['MID', 'FWD', 'DEF', 'MID'],
            'player_season_appearances': [20, 15, 25, 18],
            'player_season_xgbuildup': [5.0, 8.2, 2.1, 6.3],
            'match_avg_minutes_per_match': [65, 45, 80, 55],
            'career_stage_category': ['Mid_Career', 'Early_Career', 'Mid_Career', 'Early_Career']
        })
        
        template_csv = sample_data.to_csv(index=False)
        st.download_button(
            label="📥 Download Template",
            data=template_csv,
            file_name="player_data_template.csv",
            mime="text/csv",
            use_container_width=True
        )
    
    # Process uploaded file
    if uploaded_file is not None:
        try:
            batch_df = pd.read_csv(uploaded_file)
            
            st.success(f"✅ Successfully loaded {len(batch_df)} players")
            
            # Data preview
            with st.expander("📋 Data Preview", expanded=True):
                st.dataframe(batch_df.head(10), use_container_width=True)
                
                # Data quality check
                st.markdown("#### 🔍 Data Quality Check")
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    missing_required = []
                    required_cols = ['player_name', 'age', 'player_season_appearances', 'position']
                    for col in required_cols:
                        if col not in batch_df.columns:
                            missing_required.append(col)
                    
                    if missing_required:
                        st.error(f"❌ Missing required columns: {', '.join(missing_required)}")
                    else:
                        st.success("✅ All required columns present")
                
                with col2:
                    null_counts = batch_df.isnull().sum().sum()
                    if null_counts > 0:
                        st.warning(f"⚠️ {null_counts} missing values detected")
                    else:
                        st.success("✅ No missing values")
                
                with col3:
                    duplicate_names = batch_df['player_name'].duplicated().sum()
                    if duplicate_names > 0:
                        st.warning(f"⚠️ {duplicate_names} duplicate player names")
                    else:
                        st.success("✅ No duplicate names")
            
            # Analysis options
            st.markdown("---")
            st.markdown("### ⚙️ Analysis Options")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                include_confidence = st.checkbox("Include confidence intervals", value=True)
                
            with col2:
                generate_insights = st.checkbox("Generate team insights", value=True)
                
            with col3:
                create_visualizations = st.checkbox("Create visualizations", value=True)
            
            # Analyze button
            st.markdown("---")
            
            col_analyze1, col_analyze2, col_analyze3 = st.columns([1, 2, 1])
            
            with col_analyze2:
                analyze_button = st.button("🚀 Analyze All Players", 
                                         use_container_width=True, 
                                         type="primary")
            
            # Perform analysis
            if analyze_button:
                with st.spinner("🔮 Analyzing players... This may take a moment."):
                    results = []
                    progress_bar = st.progress(0)
                    
                    for idx, (_, row) in enumerate(batch_df.iterrows()):
                        # Prepare input data with defaults
                        input_data = {
                            'player_name': row.get('player_name', f'Player_{idx}'),
                            'age': row.get('age', 25),
                            'player_season_appearances': row.get('player_season_appearances', 20),
                            'position': row.get('position', 'MID'),
                            'player_season_xgbuildup': row.get('player_season_xgbuildup', 5.0),
                            'player_season_xgchain': row.get('player_season_xgchain', 8.0),
                            'match_avg_minutes_per_match': row.get('match_avg_minutes_per_match', 60.0),
                            'match_minutes_coefficient_variation': row.get('match_minutes_coefficient_variation', 0.5),
                            'player_season_fhalf_pressures_90': row.get('player_season_fhalf_pressures_90', 15.0),
                            'player_season_long_balls_90': row.get('player_season_long_balls_90', 5.0),
                            'total_records_per_player': row.get('total_records_per_player', 3),
                            'player_record_number': row.get('player_record_number', 2),
                            'is_latest_record': row.get('is_latest_record', 1),
                            'cumulative_appearances': row.get('cumulative_appearances', 60),
                            'career_stage_category': row.get('career_stage_category', 'Mid_Career'),
                            'age_appearances_interaction': row.get('age', 25) * row.get('player_season_appearances', 20)
                        }
                        
                        try:
                            prediction, conf_lower, conf_upper = make_prediction(input_data, model, scaler, feature_names)
                            
                            # Categorize player
                            if prediction > 2500:
                                category = 'Key Player'
                                category_color = '#28a745'
                            elif prediction > 1500:
                                category = 'Regular'
                                category_color = '#17a2b8'
                            elif prediction > 500:
                                category = 'Rotation'
                                category_color = '#ffc107'
                            else:
                                category = 'Limited'
                                category_color = '#dc3545'
                            
                            results.append({
                                'Player Name': input_data['player_name'],
                                'Age': input_data['age'],
                                'Position': input_data['position'],
                                'Appearances': input_data['player_season_appearances'],
                                'Predicted Minutes': round(prediction),
                                'Confidence Lower': round(conf_lower) if include_confidence else None,
                                'Confidence Upper': round(conf_upper) if include_confidence else None,
                                'Equivalent Matches': round(prediction/90, 1),
                                'Player Category': category,
                                'Category Color': category_color,
                                'Avg Min/Match': round(input_data['match_avg_minutes_per_match'], 1)
                            })
                            
                        except Exception as e:
                            st.warning(f"Could not predict for {input_data['player_name']}: {e}")
                        
                        # Update progress
                        progress_bar.progress((idx + 1) / len(batch_df))
                    
                    progress_bar.empty()
                    
                    if results:
                        results_df = pd.DataFrame(results)
                        st.session_state.batch_results = results_df
                        
                        # Display results
                        display_batch_results(results_df, include_confidence, generate_insights, create_visualizations)
                    else:
                        st.error("❌ No successful predictions generated")
                        
        except Exception as e:
            st.error(f"❌ Error processing file: {str(e)}")
            st.info("Please ensure your CSV file is properly formatted and try again.")
    
    # Display cached results if available
    elif st.session_state.batch_results is not None:
        st.info("📊 Showing previous analysis results")
        display_batch_results(st.session_state.batch_results, True, True, True)

def display_batch_results(results_df, include_confidence, generate_insights, create_visualizations):
    """Display comprehensive batch analysis results"""
    
    st.markdown("---")
    st.markdown("## 📊 Analysis Results")
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Players", len(results_df))
    
    with col2:
        avg_minutes = results_df['Predicted Minutes'].mean()
        st.metric("Average Minutes", f"{avg_minutes:.0f}")
    
    with col3:
        key_players = len(results_df[results_df['Player Category'] == 'Key Player'])
        st.metric("Key Players", key_players)
    
    with col4:
        total_minutes = results_df['Predicted Minutes'].sum()
        st.metric("Total Squad Minutes", f"{total_minutes:,.0f}")
    
    # Results table
    st.markdown("### 📋 Detailed Results")
    
    # Filter options
    col1, col2, col3 = st.columns(3)
    
    with col1:
        position_filter = st.multiselect(
            "Filter by Position",
            options=results_df['Position'].unique(),
            default=results_df['Position'].unique()
        )
    
    with col2:
        category_filter = st.multiselect(
            "Filter by Category",
            options=results_df['Player Category'].unique(),
            default=results_df['Player Category'].unique()
        )
    
    with col3:
        min_minutes = st.slider(
            "Minimum Predicted Minutes",
            min_value=0,
            max_value=int(results_df['Predicted Minutes'].max()),
            value=0
        )
    
    # Apply filters
    filtered_df = results_df[
        (results_df['Position'].isin(position_filter)) &
        (results_df['Player Category'].isin(category_filter)) &
        (results_df['Predicted Minutes'] >= min_minutes)
    ]
    
    # Display filtered results
    display_columns = ['Player Name', 'Age', 'Position', 'Appearances', 'Predicted Minutes', 
                      'Equivalent Matches', 'Player Category']
    
    if include_confidence:
        display_columns.extend(['Confidence Lower', 'Confidence Upper'])
    
    st.dataframe(
        filtered_df[display_columns].style.background_gradient(subset=['Predicted Minutes']),
        use_container_width=True,
        height=400
    )
    
    # Visualizations
    if create_visualizations:
        st.markdown("### 📈 Visual Analysis")
        
        # Distribution chart
        col1, col2 = st.columns(2)
        
        with col1:
            fig_dist = px.histogram(
                filtered_df, 
                x='Predicted Minutes',
                nbins=20,
                title="Distribution of Predicted Minutes",
                color_discrete_sequence=['#667eea']
            )
            fig_dist.update_layout(
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
            )
            st.plotly_chart(fig_dist, use_container_width=True)
        
        with col2:
            fig_category = px.pie(
                filtered_df.groupby('Player Category').size().reset_index(name='Count'),
                values='Count',
                names='Player Category',
                title="Player Category Distribution",
                color_discrete_sequence=['#dc3545', '#ffc107', '#17a2b8', '#28a745']
            )
            fig_category.update_layout(
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
            )
            st.plotly_chart(fig_category, use_container_width=True)
        
        # Position analysis
        fig_position = px.box(
            filtered_df,
            x='Position',
            y='Predicted Minutes',
            title="Predicted Minutes by Position",
            color='Position'
        )
        fig_position.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
        )
        st.plotly_chart(fig_position, use_container_width=True)
        
        # Age vs Minutes scatter
        fig_scatter = px.scatter(
            filtered_df,
            x='Age',
            y='Predicted Minutes',
            size='Appearances',
            color='Player Category',
            hover_data=['Player Name', 'Position'],
            title="Age vs Predicted Minutes (Size = Appearances)",
            color_discrete_sequence=['#dc3545', '#ffc107', '#17a2b8', '#28a745']
        )
        fig_scatter.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
        )
        st.plotly_chart(fig_scatter, use_container_width=True)
    
    # Team insights
    if generate_insights:
        st.markdown("### 💡 Team Insights")
        
        insights = generate_team_insights(filtered_df)
        
        for insight in insights:
            st.markdown(f"""
            <div style="background: {insight['color']}; color: white; padding: 1rem; 
                        border-radius: 10px; margin: 0.5rem 0;">
                <strong>{insight['title']}</strong><br>
                {insight['description']}
            </div>
            """, unsafe_allow_html=True)
    
    # Export options
    st.markdown("---")
    st.markdown("### 📥 Export Results")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        # CSV export
        csv = filtered_df.to_csv(index=False)
        st.download_button(
            label="📊 Download as CSV",
            data=csv,
            file_name=f"player_predictions_{datetime.now().strftime('%Y%m%d_%H%M')}.csv",
            mime="text/csv",
            use_container_width=True
        )
    
    with col2:
        # Summary report
        summary_report = generate_summary_report(filtered_df)
        st.download_button(
            label="📄 Download Summary Report",
            data=summary_report,
            file_name=f"team_analysis_report_{datetime.now().strftime('%Y%m%d_%H%M')}.txt",
            mime="text/plain",
            use_container_width=True
        )
    
    with col3:
        if st.button("🗑️ Clear Results", use_container_width=True):
            st.session_state.batch_results = None
            st.rerun()

def generate_team_insights(results_df):
    """Generate actionable team insights"""
    
    insights = []
    
    # Squad depth analysis
    key_players = len(results_df[results_df['Player Category'] == 'Key Player'])
    total_players = len(results_df)
    
    if key_players < 11:
        insights.append({
            'title': '⚠️ Squad Depth Concern',
            'description': f'Only {key_players} key players identified. Consider strengthening squad depth.',
            'color': '#dc3545'
        })
    elif key_players > 16:
        insights.append({
            'title': '💰 Potential Cost Optimization',
            'description': f'{key_players} key players may indicate high wage costs. Review squad efficiency.',
            'color': '#ffc107'
        })
    else:
        insights.append({
            'title': '✅ Balanced Squad',
            'description': f'{key_players} key players suggests good squad balance.',
            'color': '#28a745'
        })
    
    # Age analysis
    avg_age = results_df['Age'].mean()
    if avg_age > 28:
        insights.append({
            'title': '👴 Aging Squad',
            'description': f'Average age of {avg_age:.1f} suggests focus on youth development.',
            'color': '#ffc107'
        })
    elif avg_age < 23:
        insights.append({
            'title': '🌱 Young Squad',
            'description': f'Average age of {avg_age:.1f} indicates potential for growth.',
            'color': '#17a2b8'
        })
    
    # Position analysis
    position_counts = results_df['Position'].value_counts()
    if 'DEF' in position_counts and position_counts['DEF'] < 4:
        insights.append({
            'title': '🛡️ Defensive Shortage',
            'description': 'Consider strengthening defensive options.',
            'color': '#dc3545'
        })
    
    return insights

def generate_summary_report(results_df):
    """Generate a text summary report"""
    
    report = f"""
EFL LEAGUE ONE PLAYER ANALYSIS REPORT
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

SQUAD OVERVIEW:
- Total Players Analyzed: {len(results_df)}
- Average Predicted Minutes: {results_df['Predicted Minutes'].mean():.0f}
- Total Squad Minutes: {results_df['Predicted Minutes'].sum():,.0f}

PLAYER CATEGORIES:
- Key Players (>2500 min): {len(results_df[results_df['Player Category'] == 'Key Player'])}
- Regular Starters (1500-2500 min): {len(results_df[results_df['Player Category'] == 'Regular'])}
- Rotation Players (500-1500 min): {len(results_df[results_df['Player Category'] == 'Rotation'])}
- Limited Role (<500 min): {len(results_df[results_df['Player Category'] == 'Limited'])}

POSITION BREAKDOWN:
{results_df['Position'].value_counts().to_string()}

TOP 5 PREDICTED MINUTES:
{results_df.nlargest(5, 'Predicted Minutes')[['Player Name', 'Position', 'Predicted Minutes']].to_string(index=False)}

AGE ANALYSIS:
- Average Age: {results_df['Age'].mean():.1f} years
- Youngest Player: {results_df['Age'].min()} years
- Oldest Player: {results_df['Age'].max()} years

RECOMMENDATIONS:
- Monitor key players for injury prevention
- Develop rotation strategies for regular starters  
- Focus development resources on high-potential players
- Consider squad balance across positions and age groups
"""
    
    return report