import streamlit as st
import hashlib
import json
import os
from datetime import datetime
import pandas as pd

# Import page modules
from pages_all import home, single_prediction, batch_prediction, model_insights, about
from utils import auth

# Page configuration
st.set_page_config(
    page_title="EFL League One - Player Minutes Predictor",
    page_icon="⚽",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Enhanced CSS for professional styling
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    .main {
        font-family: 'Inter', sans-serif;
    }
    
    /* Header styling */
    .main-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 2rem;
        border-radius: 15px;
        text-align: center;
        margin-bottom: 2rem;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }

    .main-headerr {
        background: linear-gradient(135deg, #3F5EFB, #f5c6cb);
        color: white;
        padding: 2rem;
        border-radius: 15px;
        text-align: center;
        margin-bottom: 2rem;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }
    
    .main-header h1 {
        font-size: 2.5rem;
        font-weight: 700;
        margin: 0;
        text-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }
    
    .main-header p {
        font-size: 1.1rem;
        margin: 0.5rem 0 0 0;
        opacity: 0.9;
    }
    
    /* Navigation styling */
    .nav-container {
        background: white;
        border-radius: 15px;
        padding: 1.5rem;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        margin-bottom: 2rem;
    }
    
    /* Login form styling */
    .login-container {
        background: white;
        padding: 3rem;
        border-radius: 20px;
        box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        max-width: 400px;
        margin: 2rem auto;
    }
    
    .login-header {
        text-align: center;
        margin-bottom: 2rem;
    }
    
    .login-header h2 {
        color: #333;
        font-weight: 600;
        margin-bottom: 0.5rem;
    }
    
    .login-header p {
        color: #666;
        font-size: 0.9rem;
    }
    
    /* Button styling */
    .stButton > button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 10px;
        padding: 0.75rem 2rem;
        font-weight: 500;
        font-size: 1rem;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
    }
    
    /* Sidebar styling */
    .css-1d391kg {
        background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
    }
    
    .css-1d391kg .css-1v0mbdj {
        color: white;
    }
    
    /* Metric cards */
    .metric-card {
        background: white;
        padding: 1.5rem;
        border-radius: 15px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        border-left: 4px solid #667eea;
        margin: 1rem 0;
        transition: transform 0.2s ease;
    }
    
    .metric-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.12);
    }
    
    /* Alert styling */
    .alert-success {
        background: linear-gradient(135deg, #d4edda, #c3e6cb);
        border: 1px solid #c3e6cb;
        color: #155724;
        padding: 1rem;
        border-radius: 10px;
        margin: 1rem 0;
    }
    
    .alert-error {
        background: linear-gradient(135deg, #f8d7da, #f5c6cb);
        border: 1px solid #f5c6cb;
        color: #721c24;
        padding: 1rem;
        border-radius: 10px;
        margin: 1rem 0;
    }
    
    /* User info styling */
    .user-info {
        background: linear-gradient(135deg, #3F5EFB, #f5c6cb);
        backdrop-filter: blur(10px);
        border-radius: 10px;
        padding: 1rem;
        margin: 1rem 0;
        color: white;
    }
    
    /* Hide streamlit elements */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    .stDeployButton {display:none;}
    
    /* Custom scrollbar */
    ::-webkit-scrollbar {
        width: 8px;
    }
    
    ::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb {
        background: #667eea;
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: #5a67d8;
    }
</style>
""", unsafe_allow_html=True)

def main():
    # Initialize session state
    if 'authenticated' not in st.session_state:
        st.session_state.authenticated = False
    if 'username' not in st.session_state:
        st.session_state.username = None
    if 'user_role' not in st.session_state:
        st.session_state.user_role = None
    if 'navigation_target' not in st.session_state:
        st.session_state.navigation_target = None
    
    # Check authentication
    if not st.session_state.authenticated:
        show_auth_page()
    else:
        show_main_app()

def show_auth_page():
    """Display login/signup page"""
    
    # Center the login form
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        st.markdown(f"""
            <div class="main-headerr">
                <h1>⚽ EFL League One Player Minutes Predictor</h1>
                <p>Advanced Machine Learning for Football Analytics</p>
            </div>
            """, unsafe_allow_html=True)
        
        # Tab selection for login/signup
        tab1, tab2 = st.tabs(["🔐 Login", "📝 Sign Up"])
        
        with tab1:
            show_login_form()
        
        with tab2:
            show_signup_form()

def show_login_form():
    """Display login form"""
    with st.form("login_form"):
        st.markdown("### Welcome Back!")
        
        username = st.text_input("Username", placeholder="Enter your username")
        password = st.text_input("Password", type="password", placeholder="Enter your password")
        
        # col1, col2 = st.columns(2)
        # with col1:
        login_button = st.form_submit_button("🚀 Login", use_container_width=True)
        # with col2:
        #     demo_button = st.form_submit_button("👁️ Demo Mode", use_container_width=True)
        
        if login_button:
            if auth.verify_user(username, password):
                st.session_state.authenticated = True
                st.session_state.username = username
                st.session_state.user_role = auth.get_user_role(username)
                st.success("✅ Login successful!")
                st.rerun()
            else:
                st.error("❌ Invalid username or password")
        
        # if demo_button:
        #     st.session_state.authenticated = True
        #     st.session_state.username = "demo_user"
        #     st.session_state.user_role = "demo"
        #     st.info("🎭 Logged in as Demo User")
        #     st.rerun()

def show_signup_form():
    """Display signup form"""
    with st.form("signup_form"):
        st.markdown("### Create Your Account")
        
        new_username = st.text_input("Choose Username", placeholder="Enter desired username")
        new_email = st.text_input("Email Address", placeholder="Enter your email")
        new_password = st.text_input("Create Password", type="password", placeholder="Create a strong password")
        confirm_password = st.text_input("Confirm Password", type="password", placeholder="Confirm your password")
        
        # Role selection
        role = st.selectbox("Account Type", ["analyst", "coach", "admin"], 
                           help="Select your role in the organization")
        
        signup_button = st.form_submit_button("🎯 Create Account", use_container_width=True)
        
        if signup_button:
            if not all([new_username, new_email, new_password, confirm_password]):
                st.error("❌ Please fill in all fields")
            elif new_password != confirm_password:
                st.error("❌ Passwords do not match")
            elif len(new_password) < 6:
                st.error("❌ Password must be at least 6 characters")
            elif auth.user_exists(new_username):
                st.error("❌ Username already exists")
            else:
                if auth.create_user(new_username, new_email, new_password, role):
                    st.success("✅ Account created successfully! Please login.")
                else:
                    st.error("❌ Failed to create account")

def show_main_app():
    """Display main application after authentication"""
    
    # Header
    st.markdown(f"""
    <div class="main-header">
        <h1>⚽ EFL League One Player Minutes Predictor</h1>
        <p>Advanced Machine Learning for Football Analytics</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Sidebar with user info and navigation
    with st.sidebar:
        # User information
        st.markdown(f"""
        <div class="user-info">
            <h3>👤 Welcome, {st.session_state.username}!</h3>
            <p>Role: {st.session_state.user_role.title()}</p>
            <p>Session: {datetime.now().strftime('%d %b %Y, %H:%M')}</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("---")
        
        # Navigation
        st.markdown("### 🧭 Navigation")
        
        pages = {
            "🏠 Dashboard": "home",
            "🔮 Single Prediction": "single_prediction", 
            "📊 Batch Analysis": "batch_prediction",
            "📋 About": "about"
        }
        
        # Role-based access control
        if st.session_state.user_role == "demo":
            # Demo users have limited access
            available_pages = {k: v for k, v in pages.items() if v in ["home", "single_prediction", "about"]}
            st.info("🎭 Demo Mode: Limited features available")
        else:
            available_pages = pages
        
        # Handle navigation from quick buttons
        if 'navigation_target' in st.session_state and st.session_state.navigation_target:
            if st.session_state.navigation_target in available_pages:
                default_index = list(available_pages.keys()).index(st.session_state.navigation_target)
                st.session_state.navigation_target = None  # Clear the target
            else:
                default_index = 0
        else:
            default_index = 0
        
        selected_page = st.selectbox(
            "Choose a page:", 
            list(available_pages.keys()),
            index=default_index,
            key="page_selector"
        )
        
        page_key = available_pages[selected_page]
        
        st.markdown("---")
        
        # Quick stats (placeholder)
        st.markdown("### 📊 Quick Stats")
        
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Predictions Made", "1,234", "↗️ 12%")
        with col2:
            st.metric("Accuracy", "98.3%", "↗️ 0.5%")
        
        st.markdown("---")
        
        # Logout button
        if st.button("🚪 Logout", use_container_width=True):
            st.session_state.authenticated = False
            st.session_state.username = None
            st.session_state.user_role = None
            st.rerun()
    
    # Load selected page
    try:
        if page_key == "home":
            home.show()
        elif page_key == "single_prediction":
            single_prediction.show()
        elif page_key == "batch_prediction":
            batch_prediction.show()
        elif page_key == "model_insights":
            model_insights.show()
        elif page_key == "about":
            about.show()
    except Exception as e:
        st.error(f"Error loading page: {str(e)}")
        st.info("Please try refreshing the page or contact support.")

if __name__ == "__main__":
    main()