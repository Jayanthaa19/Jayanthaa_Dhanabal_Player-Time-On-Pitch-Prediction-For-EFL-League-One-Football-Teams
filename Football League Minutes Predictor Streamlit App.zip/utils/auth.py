# utils/auth.py
import hashlib
import json
import os
from datetime import datetime
import streamlit as st

# File to store user data
USERS_FILE = "data/users.json"

def ensure_data_directory():
    """Ensure the data directory exists"""
    os.makedirs("data", exist_ok=True)

def hash_password(password):
    """Hash password using SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def load_users():
    """Load users from JSON file"""
    ensure_data_directory()
    
    if not os.path.exists(USERS_FILE):
        # Create default admin user
        default_users = {
            "admin": {
                "password": hash_password("admin123"),
                "email": "admin@efl-predictor.com",
                "role": "admin",
                "created_at": datetime.now().isoformat(),
                "last_login": None
            },
            "demo": {
                "password": hash_password("demo123"),
                "email": "demo@efl-predictor.com", 
                "role": "demo",
                "created_at": datetime.now().isoformat(),
                "last_login": None
            }
        }
        
        with open(USERS_FILE, 'w') as f:
            json.dump(default_users, f, indent=2)
        
        return default_users
    
    try:
        with open(USERS_FILE, 'r') as f:
            return json.load(f)
    except:
        return {}

def save_users(users):
    """Save users to JSON file"""
    ensure_data_directory()
    
    try:
        with open(USERS_FILE, 'w') as f:
            json.dump(users, f, indent=2)
        return True
    except:
        return False

def verify_user(username, password):
    """Verify user credentials"""
    if not username or not password:
        return False
    
    users = load_users()
    
    if username in users:
        stored_password = users[username]["password"]
        if stored_password == hash_password(password):
            # Update last login
            users[username]["last_login"] = datetime.now().isoformat()
            save_users(users)
            return True
    
    return False

def create_user(username, email, password, role="analyst"):
    """Create a new user"""
    if not username or not email or not password:
        return False
    
    users = load_users()
    
    # Check if user already exists
    if username in users:
        return False
    
    # Add new user
    users[username] = {
        "password": hash_password(password),
        "email": email,
        "role": role,
        "created_at": datetime.now().isoformat(),
        "last_login": None
    }
    
    return save_users(users)

def user_exists(username):
    """Check if user exists"""
    users = load_users()
    return username in users

def get_user_role(username):
    """Get user role"""
    users = load_users()
    if username in users:
        return users[username].get("role", "analyst")
    return None

def get_user_info(username):
    """Get user information"""
    users = load_users()
    if username in users:
        user_data = users[username].copy()
        # Remove password from returned data
        user_data.pop("password", None)
        return user_data
    return None

def update_user_info(username, updates):
    """Update user information"""
    users = load_users()
    
    if username in users:
        for key, value in updates.items():
            if key != "password":  # Don't allow direct password updates
                users[username][key] = value
        
        users[username]["updated_at"] = datetime.now().isoformat()
        return save_users(users)
    
    return False

def change_password(username, old_password, new_password):
    """Change user password"""
    users = load_users()
    
    if username in users:
        # Verify old password
        if users[username]["password"] == hash_password(old_password):
            users[username]["password"] = hash_password(new_password)
            users[username]["password_changed_at"] = datetime.now().isoformat()
            return save_users(users)
    
    return False

def get_all_users():
    """Get all users (admin only)"""
    users = load_users()
    # Remove passwords from returned data
    safe_users = {}
    for username, data in users.items():
        safe_users[username] = {k: v for k, v in data.items() if k != "password"}
    return safe_users

def delete_user(username):
    """Delete a user (admin only)"""
    users = load_users()
    
    if username in users and username != "admin":  # Protect admin account
        del users[username]
        return save_users(users)
    
    return False